package com.example.trainway;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    CardView cardView;
    TextView textView_signup, textView_login;
    private String url = "https://trainway-9a85a-default-rtdb.firebaseio.com";  // URL for firebase database
    private static final String TAG = "MyActivity";
    private FirebaseDatabase database = FirebaseDatabase.getInstance(url);

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
        cardView = findViewById(R.id.cardView_login);


        Button login_button = findViewById(R.id.login_button);

        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //do the login stuff such as validating login info and then go to the next activity
                Intent intent = new Intent(MainActivity.this, mainContent.class);
                startActivity(intent);
            }
        });

        //setContentView(R.layout.ticket_create);

        // set user's name to title
       // TextView title = findViewById(R.id.title);
        //TODO: set User's to actual name
       // title.setText("User's Tickets");
    }





    public void createTicket(View view)
    {
        DatabaseReference myRef = database.getReference("message");
        myRef.setValue("Hello, World!");
        // Write Ticket to Database
        EditText Id = findViewById(R.id.idText);
        EditText route = findViewById(R.id.routeText);

        // Copies user input into ticket creator
        EditText price = findViewById(R.id.priceText);
        String priced = price.getText().toString();
        double finalPrice= Double.parseDouble(priced);
        EditText time = findViewById(R.id.timeText);
        EditText date = findViewById(R.id.dateText);
        EditText count = findViewById(R.id.countText);
        String tCount= count.getText().toString();
        int finalCounter = Integer.parseInt(tCount);
        TicketMain.Ticket test = new TicketMain.Ticket();
        test.newTicket("test",10,"Dallas","11/23","10:30",50);
        test.newTicket(Id.getText().toString(),finalPrice,route.getText().toString(),date.getText().toString(),time.getText().toString(),finalCounter);

    }

    public void deleteTicket(){

    }
    public void buyTicket(View view){

    }

    public void refundTicket(){

    }

    public void signupRedirect(View view) {
        setContentView(R.layout.activity_sign_up);
        Button sign_up_button = findViewById(R.id.signup_button);
        sign_up_button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //do the signup stuff and then go to the login page after successfully sign up, save the user info in the database
            }
        });
    }

    public void loginRedirect(View view) {
        setContentView(R.layout.activity_login);
    }
}

